var Empleado = require('./modelo/empleado');


// Obtiene todos los objetos Empleado de la base de datos
exports.getEmpleado = function (req, res) {
    Empleado.find(
            function (err, empleado) {
                if (err) {
                    res.send(err);
                }
                res.json(empleado); // devuelve todas las Empleados en JSON		
            }
    );
};

// Guarda un objeto Empleado en base de datos
exports.setEmpleado = function (req, res) {

    // Creo el objeto Empleado
    Empleado.create(
            {
                nombre: req.body.nombre,
                apellido: req.body.apellido,
                dni: req.body.dni,
                departamento: req.body.departamento,
                descripcion: req.body.descripcion,
            },
            function (err, empleado) {
                if (err) {
                    res.send(err);
                }

                // Obtine y devuelve todas las empleados tras crear una de ellas
                Empleado.find(function (err, empleado) {
                    if (err) {
                        res.send(err);
                    }
                    res.json(empleado);
                });
            });
};

// Modificamos un objeto Empleado de la base de datos
exports.updateEmpleado = function (req, res) {
    Empleado.update({_id: req.params.empleado_id},
            {$set: {
                    nnombre: req.body.nombre,
                    apellido: req.body.apellido,
                    dni: req.body.dni,
                    departamento: req.body.departamento,
                    descripcion: req.body.descripcion,
                }},
            function (err, empleado) {
                if (err) {
                    res.send(err);
                }
                // Obtine y devuelve todas las empleados tras crear una de ellas
                Empleado.find(function (err, empleado) {
                    if (err) {
                        res.send(err);
                    }
                    res.json(empleado);
                });
            });
};

// Elimino un objeto Empleado de la base de Datos
exports.removeEmpleado = function (req, res) {
    Empleado.remove({_id: req.params.empleado_id}, function (err, empleado) {
        if (err) {
            res.send(err);
        }

        // Obtine y devuelve todas las empleados tras borrar una de ellas
        Empleado.find(function (err, empleado) {
            if (err)
                res.send(err)
            res.json(empleado);
        });
    });
};