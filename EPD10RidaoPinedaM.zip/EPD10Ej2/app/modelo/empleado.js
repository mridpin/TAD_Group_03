var mongoose = require('mongoose');

module.exports = mongoose.model('Empleado', {
	nombre: String,
	apellido: String,
	dni: String,
        departamento: String,
        descripcion: String
});