var Empleado = require('./modelo/empleado');
var Controller = require ('./controller');

module.exports = function(app) {

	// devolver todos los Empleados
	app.get('/api/empleado', Controller.getEmpleado);
	// Crear una nueva Empleado
	app.post('/api/empleado', Controller.setEmpleado);
	// Modificar los datos de una Empleado
	app.put('/api/empleado/:empleado_id', Controller.updateEmpleado);
	// Borrar una Empleado
	app.delete('/api/empleado/:empleado_id', Controller.removeEmpleado);

	// application -------------------------------------------------------------
	app.get('*', function(req, res) {
		res.sendfile('./angular/index.html'); // Carga única de la vista
	});
};