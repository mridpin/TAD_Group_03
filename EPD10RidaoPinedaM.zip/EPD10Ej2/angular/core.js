angular.module('MainApp', [])


function mainController($scope, $http) {
	$scope.newEmpleado = {};
	$scope.empleados = {};
	$scope.selected = false;

	// Obtenemos todos los datos de la base de datos
	$http.get('/api/empleado').success(function(data) {
		$scope.empleados = data;
	})
	.error(function(data) {
		console.log('Error: ' + data);
	});


	// Función para registrar a una empleado
	$scope.registrarEmpleado = function() {
		$http.post('/api/empleado', $scope.newEmpleado)
		.success(function(data) {
				$scope.newEmpleado = {}; // Borramos los datos del formulario
				$scope.empleados = data;
			})
		.error(function(data) {
			console.log('Error: ' + data);
		});
	};

	// Función para editar los datos de una empleado
	$scope.modificarEmpleado = function(newEmpleado) {
		$http.put('/api/empleado/' + $scope.newEmpleado._id, $scope.newEmpleado)
		.success(function(data) {
				$scope.newEmpleado = {}; // Borramos los datos del formulario
				$scope.empleados = data;
				$scope.selected = false;
			})
		.error(function(data) {
			console.log('Error: ' + data);
		});
	};

	// Función que borra un objeto empleado conocido su id
	$scope.borrarEmpleado = function(newEmpleado) {
		$http.delete('/api/empleado/' + $scope.newEmpleado._id)
		.success(function(data) {
			$scope.newEmpleado = {};
			$scope.empleados = data;
			$scope.selected = false;
		})
		.error(function(data) {
			console.log('Error: ' + data);
		});
	};

	// Función para coger el objeto seleccionado en la tabla
	$scope.selectEmpleado = function(empleado) {
		$scope.newEmpleado = empleado;
		$scope.selected = true;
		console.log($scope.newEmpleado, $scope.selected);
	};
}