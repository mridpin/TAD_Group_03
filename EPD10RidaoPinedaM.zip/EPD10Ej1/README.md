MEAN_ejemplo
============

Sencillo ejemplo de una aplicación hecha en MEAN (Mongo-Express-Angular-Node)

Para poder ejecutar este proyecto teneis que:
  1.- Instalar MongoDB
  2.- Instalar express
  3.- Instalar NodeJS

Se recomienda ejecutar este proyecto en un Linux o Unix ya que la instalación de MongoDB y sobre todo de Express y NodeJS en un Sistema Operativo Windows es bastante tediosa.
